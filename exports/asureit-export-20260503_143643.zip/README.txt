﻿AsureIT Database Export
=======================
Exported at : 2026-05-03 14:36:56
Database    : asureit
Tables      : 205 (public schema)
Postgres    : psql (PostgreSQL) 15.17
Dump format : Plain SQL (UTF-8, --clean --if-exists)

Files in this bundle
--------------------
  database.sql    Full schema + all data (run psql to restore)
  uploads/        Vendor-uploaded files (logos, attachments, etc.)
  import-db.ps1   One-command restore script for Windows + Docker
  README.txt      This file

Quick restore (Windows + Docker Desktop)
-----------------------------------------
  1. Install Docker Desktop and start it.
  2. Clone/copy the AsureIT project to your machine.
  3. Extract this zip anywhere, then run:

       .\import-db.ps1 -ExportDir "C:\path\to\this-folder"

  4. When prompted type 'yes' to confirm the restore.
  5. After import:   docker compose up -d
     - Vendor app  : http://localhost:3001
     - Storefront  : http://localhost:3002
     - API docs    : http://localhost:8000/docs

Manual restore (if import-db.ps1 is unavailable)
-------------------------------------------------
  docker compose up -d postgres
  docker cp database.sql asureit-postgres:/tmp/restore.sql
  docker exec asureit-postgres psql -U postgres -d postgres -c "DROP DATABASE IF EXISTS asureit; CREATE DATABASE asureit OWNER postgres;"
  docker exec asureit-postgres psql -U postgres -d asureit -f /tmp/restore.sql
  docker compose up -d
